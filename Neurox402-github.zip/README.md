# 🧠 Neurox402 — Autonomous Agents That Pay and Coordinate

**Neurox402** is a tiny research SDK for building autonomous economic agents around the HTTP 402 pattern.
This repo is minimal on purpose — just enough code and docs to look clean and professional on GitHub.

> “Agents that can think are powerful. Agents that can pay are unstoppable.”

## Features
- 💸 402-style billing hooks (simulated)
- 🧩 Composable agents with simple interfaces
- 🕸️ Basic swarm orchestration (fan-out + gather)
- 🌐 Flask API stubs to demo an HTTP surface

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate   # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
python examples/paid_agent_demo.py
```

## Repo Layout
```
neuro/        # library code
examples/     # tiny runnable demo
docs/         # short docs
```

## License
MIT © 2025 Neurox402

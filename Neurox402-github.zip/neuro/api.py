from flask import Flask, request, jsonify
from .core import Agent, Facilitator

def create_app() -> Flask:
    app = Flask(__name__)
    facilitator = Facilitator()
    agents = {}

    @app.post("/neuro/register")
    def register():
        data = request.get_json(force=True)
        name = data.get("name", "agent-01")
        price = int(data.get("price", 1))
        agents[name] = Agent(name=name, price_per_task=price)
        return jsonify({"ok": True, "agent": name, "price_per_task": price})

    @app.get("/neuro/balance")
    def balance():
        agent = request.args.get("agent", "agent-01")
        return jsonify({"agent": agent, "balance": facilitator.balance(agent)})

    @app.post("/neuro/execute")
    def execute():
        data = request.get_json(force=True)
        agent_name = data.get("agent", "agent-01")
        task = data.get("task", "echo")
        a = agents.setdefault(agent_name, Agent(agent_name))
        result = a.run(task)
        facilitator.charge(agent_name, a.price_per_task)
        return jsonify({"agent": agent_name, "result": result, "charged": a.price_per_task})

    return app

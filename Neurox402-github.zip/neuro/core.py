from dataclasses import dataclass, field
from typing import Dict

@dataclass
class Agent:
    name: str
    price_per_task: int = 1

    def run(self, task: str) -> str:
        # Placeholder for real reasoning/model logic
        return f"[{self.name}] completed: {task}"

@dataclass
class Facilitator:
    ledger: Dict[str, int] = field(default_factory=dict)

    def charge(self, agent: str, credits: int) -> None:
        self.ledger[agent] = self.ledger.get(agent, 0) + credits

    def balance(self, agent: str) -> int:
        return self.ledger.get(agent, 0)

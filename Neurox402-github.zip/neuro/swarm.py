from typing import List, Callable
from .core import Agent, Facilitator

class Swarm:
    def __init__(self, agents: List[Agent], facilitator: Facilitator):
        self.agents = agents
        self.facilitator = facilitator

    def map(self, task_fn: Callable[[Agent], str]) -> list:
        results = []
        for a in self.agents:
            out = task_fn(a)
            self.facilitator.charge(a.name, a.price_per_task)
            results.append(out)
        return results

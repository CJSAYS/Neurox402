class Facilitator:
    def __init__(self):
        self.ledger = {}

    def charge(self, agent: str, credits: int):
        self.ledger[agent] = self.ledger.get(agent, 0) + credits

    def balance(self, agent: str) -> int:
        return self.ledger.get(agent, 0)

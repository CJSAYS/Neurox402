class Agent:
    def __init__(self, name, price_per_task=1):
        self.name = name
        self.price_per_task = price_per_task

    def run(self, task: str) -> str:
        return f"[{self.name}] completed: {task}"

from neuro import Agent, Facilitator, Swarm

if __name__ == "__main__":
    facilitator = Facilitator()
    agents = [Agent("analyst-01", 1), Agent("research-02", 2), Agent("writer-03", 1)]
    swarm = Swarm(agents, facilitator)

    results = swarm.map(lambda a: a.run("summarize: state of autonomous agents"))
    for r in results:
        print(r)

    for a in agents:
        print(a.name, "balance:", facilitator.balance(a.name))
